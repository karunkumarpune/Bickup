package com.app.bickup.fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.app.bickup.GoodsActivity;
import com.app.bickup.R;
import com.app.bickup.TrackDriverActivity;
import com.app.bickup.adapter.GoodsImagesAdapter;
import com.app.bickup.interfaces.GoodsImagesInterface;
import com.app.bickup.interfaces.HandlerGoodsNavigations;
import com.app.bickup.utility.CommonMethods;
import com.app.bickup.utility.ConstantValues;

import java.util.ArrayList;


public class BookingDetailsFragment extends Fragment implements View.OnClickListener,GoodsImagesInterface {


    public static String Tag=BookingDetailsFragment.class.getSimpleName();
    private Typeface  mTypefaceRegular;
    private Typeface  mTypefaceBold;
    private GoodsActivity mActivityReference;
    private Button    btnConfirmBooking;
    private EditText  edtContactNumber;
    private EditText  edtContactName;
    private TextView  txtPickupLocation;
    private TextView  txtDropLocation;
    private TextView  txtPickupContactname;
    private TextView  txtDropContactname;
    private TextView  txtPickupContactNumber;
    private TextView  txtDropContactNumber;
    private TextView  txtDescription;
    private TextView  txtPriceWithHelper;
    private TextView  txtTotalAmount;
    private TextView    btnPaidByMe;
    private TextView    btnOther;
    private TextView  txtHelerString;
    private ArrayList<Bitmap> listImages;
    private RecyclerView recyclerView;


    public BookingDetailsFragment() {
        // Required empty public constructor
        }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_booking_detail, container, false);
        initializeViews(view);
        return view;
    }

    private void setImagesList() {
        Bitmap bitmap1 = null,bitmap2=null,bitmap3=null,bitmap4=null;
        if(listImages!=null) {
            GoodsImagesAdapter goodsImagesAdapter=new GoodsImagesAdapter(mActivityReference,listImages);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(mActivityReference, LinearLayoutManager.HORIZONTAL,false);
            recyclerView.setLayoutManager(mLayoutManager);
            recyclerView.setItemAnimator(new DefaultItemAnimator());
            recyclerView.setAdapter(goodsImagesAdapter);
        }



    }

    private void initializeViews(View view) {

        mTypefaceRegular= Typeface.createFromAsset(mActivityReference.getAssets(), ConstantValues.TYPEFACE_REGULAR);
        mTypefaceBold=Typeface.createFromAsset(mActivityReference.getAssets(), ConstantValues.TYPEFACE_BOLD);
        recyclerView=(RecyclerView)view.findViewById(R.id.recyclerImages_booking);
        setImagesList();

        btnConfirmBooking=(Button)view.findViewById(R.id.btn_confirm_booking);
        btnPaidByMe=(TextView)view.findViewById(R.id.btn_paid_by_me);
        btnOther=(TextView)view.findViewById(R.id.paid_by_other);
        btnPaidByMe.setOnClickListener(this);
        btnOther.setOnClickListener(this);
        btnConfirmBooking.setOnClickListener(this);
        btnConfirmBooking.setOnClickListener(this);

        btnPaidByMe.setOnClickListener(this);
        btnOther.setOnClickListener(this);
        btnPaidByMe.setTag(false);
        btnOther.setTag(true);
        btnConfirmBooking.setTypeface(mTypefaceRegular);
        btnConfirmBooking.setTypeface(mTypefaceRegular);
        btnPaidByMe.setTypeface(mTypefaceRegular);
        btnOther.setTypeface(mTypefaceRegular);


        edtContactName=(EditText)view.findViewById(R.id.edt_contact_person_name);
        edtContactNumber=(EditText)view.findViewById(R.id.edt_contact_person_number);
        txtPickupContactname=(TextView)view.findViewById(R.id.value_pickup_contact_name);
        txtPickupContactNumber=(TextView)view.findViewById(R.id.value_pickup_contact_number);
        txtPickupLocation=(TextView)view.findViewById(R.id.value_pickup_location);

        edtContactNumber.setTypeface(mTypefaceRegular);
        edtContactName.setTypeface(mTypefaceRegular);
        txtPickupContactNumber.setTypeface(mTypefaceRegular);
        txtPickupContactname.setTypeface(mTypefaceRegular);
        txtPickupLocation.setTypeface(mTypefaceRegular);

        txtDropContactname=(TextView)view.findViewById(R.id.value_drop_contact_name);
        txtDropContactNumber=(TextView)view.findViewById(R.id.value_drop_contact_number);
        txtDropLocation=(TextView)view.findViewById(R.id.value_drop_location);

        txtDropContactNumber.setTypeface(mTypefaceRegular);
        txtDropContactname.setTypeface(mTypefaceRegular);
        txtDropLocation.setTypeface(mTypefaceRegular);

        txtDescription=(TextView)view.findViewById(R.id.value_description);
        txtPriceWithHelper=(TextView)view.findViewById(R.id.value_amount_string);
        txtTotalAmount=(TextView)view.findViewById(R.id.value_total_string);
        txtHelerString=(TextView)view.findViewById(R.id.txt_helper_string);

        txtDescription.setTypeface(mTypefaceRegular);
        txtPriceWithHelper.setTypeface(mTypefaceRegular);
        txtTotalAmount.setTypeface(mTypefaceBold);
        txtHelerString.setTypeface(mTypefaceRegular);


        setTypeFaces(view);
    }

    private void setTypeFaces(View view) {
        TextView txtPickupLocation=(TextView)view.findViewById(R.id.label_pickup_location);
        TextView txtPickupContact=(TextView)view.findViewById(R.id.label_pickup_contact);
        TextView txtDropLocation=(TextView)view.findViewById(R.id.label_drop_location);
        TextView txtDropContact=(TextView)view.findViewById(R.id.label_drop_contact);
        TextView txtLabelOfNumberHelper=(TextView)view.findViewById(R.id.label_number_of_helpers);
       // TextView txtContactPersonName=(TextView)view.findViewById(R.id.label_contact_person_name);
       // TextView txtContactPersonNumber=(TextView)view.findViewById(R.id.label_contact_person_number);
        TextView txtAmountDetails=(TextView)view.findViewById(R.id.label_amount_details);
        TextView txtDescription=(TextView)view.findViewById(R.id.label_description);
        TextView txtTypeDescription=(TextView)view.findViewById(R.id.label_types_of_goods);

        txtPickupLocation.setTypeface(mTypefaceRegular);
        txtPickupContact.setTypeface(mTypefaceRegular);
        txtAmountDetails.setTypeface(mTypefaceRegular);
        txtDropLocation.setTypeface(mTypefaceRegular);
        txtDropLocation.setTypeface(mTypefaceRegular);
        txtDropContact.setTypeface(mTypefaceRegular);
        txtLabelOfNumberHelper.setTypeface(mTypefaceRegular);
      //  txtContactPersonName.setTypeface(mTypefaceRegular);
      //  txtContactPersonNumber.setTypeface(mTypefaceRegular);
        txtDescription.setTypeface(mTypefaceRegular);
        txtTypeDescription.setTypeface(mTypefaceRegular);

    }


    private boolean validateFields() {
        if(!CommonMethods.getInstance().validateEditFeild(edtContactName.getText().toString())){
            Toast.makeText(mActivityReference, mActivityReference.getResources().getString(R.string.txt_vaidate_contact_person_name), Toast.LENGTH_SHORT).show();
            return false;
        }


        if(!CommonMethods.getInstance().validateEditFeild(edtContactNumber.getText().toString())){
            Toast.makeText(mActivityReference, mActivityReference.getResources().getString(R.string.txt_vaidate_mobile), Toast.LENGTH_SHORT).show();
            return false;
        }else{
            if(!CommonMethods.getInstance().validateMobileNumber(edtContactNumber.getText().toString(),6)){
                Toast.makeText(mActivityReference, mActivityReference.getResources().getString(R.string.txt_vaidate_mobile_number), Toast.LENGTH_SHORT).show();
                return false;
            }

        }
        return true;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivityReference=(GoodsActivity)context;

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    private void showPopUp() {
        final Dialog openDialog = new Dialog(mActivityReference);
        openDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        openDialog.setContentView(R.layout.booking_confirmation_dialog);
        openDialog.setTitle("Custom Dialog Box");
        openDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
      /*  TextView travellerName = (TextView)openDialog.findViewById(R.id.txt_traveller_name_dialog);

        TextView travellerCost = (TextView)openDialog.findViewById(R.id.txt_traveller_cost);
        ImageView travellerImage = (ImageView)openDialog.findViewById(R.id.img_traveller);
        Button btnDone = (Button)openDialog.findViewById(R.id.btn_done);
*/
        Button btnAgree = (Button)openDialog.findViewById(R.id.btn_done);
      /*  travellerName.setTypeface(mTypefaceBold);
        travellerCost.setTypeface(mTypefaceRegular);
        btnDisagree.setTypeface(mTypefaceBold);*/
//        btnAgree.setTypeface(mTypefaceBold);

        btnAgree.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openDialog.dismiss();
                Intent intent=new Intent(mActivityReference,TrackDriverActivity.class);
                startActivity(intent);
            }
        });
      /*  btnAgree.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                openDialog.dismiss();
                Intent intent=new Intent(MainActivity.this,GoodsActivity.class);
                startActivity(intent);
            }
        });*/
        openDialog.show();

    }
    @Override
    public void onClick(View view) {
        HandlerGoodsNavigations handlerGoodsNavigations=mActivityReference;
        int id=view.getId();
        switch (id){
            case R.id.btn_confirm_booking:
                if(validateFields()){
                    showPopUp();
                }
                break;
            case R.id.btn_paid_by_me:
                btnPaidByMe.setBackground(mActivityReference.getResources().getDrawable(R.drawable.sm_btn));
                btnOther.setBackgroundColor(mActivityReference.getResources().getColor(R.color.white));
                btnPaidByMe.setTextColor(mActivityReference.getResources().getColor(R.color.white));
                btnOther.setTextColor(mActivityReference.getResources().getColor(R.color.grey_text_color));
                btnPaidByMe.setTag(true);
                btnOther.setTag(false);
                break;
            case R.id.paid_by_other:
                btnPaidByMe.setBackgroundColor(mActivityReference.getResources().getColor(R.color.white));
                btnOther.setBackground(mActivityReference.getResources().getDrawable(R.drawable.sm_btn));
                btnPaidByMe.setTextColor(mActivityReference.getResources().getColor(R.color.grey_text_color));
                btnOther.setTextColor(mActivityReference.getResources().getColor(R.color.white));
                btnPaidByMe.setTag(false);
                btnOther.setTag(true);
                break;

        }
    }


    @Override
    public void setImagelist(ArrayList<Bitmap> listimage) {
        this.listImages=listimage;
    }
}
