package com.app.bickup.interfaces;

import com.app.bickup.model.User;

/**
 * Created by fluper-pc on 18/9/17.
 */

public interface GetSocialLoginResultInterface {
    public void getLoginresult(User mUser);
}
