package com.app.bickup.interfaces;

/**
 * Created by fluper-pc on 26/10/17.
 */

public interface CallTitle {

    public void calltitlefragment();
}
