package com.app.bickup.interfaces;

import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by fluper-pc on 28/9/17.
 */

public interface HandlerGoodsNavigations {

    public void callBookingDetailsFragment(ArrayList<Bitmap> listgoodsImage);
    public void callGoodsFragment();
    public void callTrackDriverActivity();

}
