package com.app.bickup.controller;

import com.app.bickup.utility.ConstantValues;

/**
 * Created by fluper-pc on 29/10/17.
 */

public class WebAPIManager {
    private static final WebAPIManager ourInstance = new WebAPIManager();

    public static WebAPIManager getInstance() {
        return ourInstance;
    }

    private WebAPIManager() {
    }


    public String getCreateUserUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user";
        return  url;
    }

    public String getUserLoginUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/login";
        return  url;
    }

    public String getVerifyUserUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/verifyOtp?";
        return  url;
    }

    public String getResenOTPdUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/resendOtp";
        return  url;
    }
    public String getSocialLoginUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/social";
        return  url;
    }

    public String getSocialSignupUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/completeSignup";
        return  url;
    }

    public String getforgotPasswordUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/forgotPassword?";
        return  url;
    }

    public String getresetPasswordUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/resetPassword?";
        return  url;
    }
    public String getchangeNumberUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/changeNumber?phone_number=";
        return  url;
    }

    public String getimageUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user";
        return  url;
    }

    public String getMapDirectionUrl(){
        String url= "https://maps.googleapis.com/maps/api/directions/json?";
        return  url;
    }

    public String getSaveAddressUrl(){
        String url= ConstantValues.BASE_URL;
        url=url+"/user/save_address";
        return  url;
    }
    public String getTypesGoods(){
        String url= ConstantValues.BASE_URL;
        url=url+"/get_goods_and_helper";
        return  url;
    }
}
