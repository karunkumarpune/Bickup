package com.app.bickup.interfaces;

import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by fluper-pc on 14/10/17.
 */

public interface GoodsImagesInterface {

    public void setImagelist(ArrayList<Bitmap> listimage);
}
